package com.scotiabank.json;

import java.util.*;

public class JsonDataObject {

  private String URL;
  private String EMAIL;
  private String PASSWORD;
  private List<String> list = new ArrayList<String>();

  @Override
  public String toString() {
    return "DataObject [URL=" + URL + ", EMAIL=" + EMAIL + ", PASWORD=" + PASSWORD + ", list=" + list + "]";
  }

  public String getURL() {
    return URL;
  }

  public String getEMAIL() {
    return EMAIL;
  }

  public String getPASSWORD() {
    return PASSWORD;
  }

  public List<String> getList() {
    return list;
  }

}